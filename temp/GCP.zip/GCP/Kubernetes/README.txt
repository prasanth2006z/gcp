https://linuxacademy.com/cp/learningpaths/preview/id/3460
https://linuxacademy.com/cp/modules/view/id/249