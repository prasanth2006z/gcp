#Planning your successful cloud migration
https://cloud.google.com/solutions/best-practices-migrating-vm-to-compute-engine
https://cloud.google.com/blog/products/gcp/the-five-phases-of-migrating-to-google-cloud-platform