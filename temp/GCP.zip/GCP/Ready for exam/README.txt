https://cloud.google.com/blog/
https://github.com/gregsramblings/google-cloud-4-words
https://gcp.solutions/
https://codelabs.developers.google.com/gdd17/