
https://cloud.google.com/solutions/dr-scenarios-planning-guide