https://cloud.google.com/solutions/big-data/
https://cloud.google.com/solutions/data-lifecycle-cloud-platform
https://gcp.solutions/